Offline POS & Accounts Pro v8.0 — Simple Blue Branding

This version removes the Dark/Gold theme and returns to the clean blue/white style.

Kept:
- Professional app icon
- Android splash screen
- Branded loading screen
- Mobile APK support
- Emergency backup/recovery features
- Beautiful dashboard
- Login, reports, charts, statements and all accounting features

Changed:
- No Dark Gold theme
- Simple Blue + Teal colors
- Cleaner, lighter appearance like the earlier versions
