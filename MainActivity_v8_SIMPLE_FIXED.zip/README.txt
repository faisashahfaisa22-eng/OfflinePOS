MainActivity v8 Simple Fixed

Fixes the GitHub compile errors:
- removes androidx.webkit.WebViewAssetLoader
- removes androidx.webkit.WebViewClientCompat
- uses standard Android WebViewClient
- loads bundled index.html from file:///android_asset/
- keeps DOM storage enabled
- keeps file chooser, backup/export bridge and printing support
- keeps simple blue status/navigation bar

Upload this file to GitHub as:
MainActivity.java
(replace the existing MainActivity.java)
