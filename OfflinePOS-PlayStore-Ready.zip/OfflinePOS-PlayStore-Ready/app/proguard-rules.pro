# Offline POS currently keeps minification disabled for release stability.
